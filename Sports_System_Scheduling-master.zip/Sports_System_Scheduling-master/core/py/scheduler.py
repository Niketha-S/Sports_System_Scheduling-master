import sys
import pandas as pd
import random
from datetime import datetime, timedelta
from typing import List, Dict


class Scheduler:
    @staticmethod
    def run(case: str = "case1") -> int:
        """
        Scheduling algorithm for different cases.

        Args:
            case (str): The test case folder name.

        Returns:
            int: Returns 0 if successful; otherwise, returns 1.
        """
        # File paths for the input CSV files
        input_teams = f"./data/{case}/team.csv"
        input_venues = f"./data/{case}/venue.csv"
        input_leagues = f"./data/{case}/league.csv"

        try:
            # Load input data
            team_df = pd.read_csv(input_teams)
            venue_df = pd.read_csv(input_venues)
            league_df = pd.read_csv(input_leagues)

            # Validate input data
            if team_df.empty or venue_df.empty or league_df.empty:
                print("Error: One or more input files are empty.")
                return 1
        except FileNotFoundError as e:
            print(f"Error: {e}")
            return 1
        except pd.errors.EmptyDataError as e:
            print(f"Error: {e}")
            return 1

        # List to hold scheduled games
        schedule_records = []

        # Add logic for different cases
        if case == "case_simple":  # Simpler scenario for a recreational league
            league = league_df.iloc[0]  # Assuming a single league for simplicity
            teams = team_df["teamId"].tolist()

            # Call the existing method for scheduling but with special parameters for the simpler case
            Scheduler.schedule_league_games(
                teams=teams,
                league=league,
                team_df=team_df,
                venue_df=venue_df,
                schedule_records=schedule_records,
                simple_case=True,  # Flag for simpler scenario
            )
        else:
            # Existing logic for other cases
            teams_by_league = team_df.groupby("leagueId")
            for league_id, league_teams in teams_by_league:
                league = league_df[league_df["leagueId"] == league_id].iloc[0]
                teams = league_teams["teamId"].tolist()
                random.shuffle(teams)  # Shuffle teams for randomness

                Scheduler.schedule_league_games(
                    teams=teams,
                    league=league,
                    team_df=team_df,
                    venue_df=venue_df,
                    schedule_records=schedule_records,
                )

        # Save the schedule to CSV and JSON files
        output_csv = f"./data/{case}/schedule.csv"
        output_json = f"./data/{case}/schedule.json"
        try:
            schedule_df = pd.DataFrame(schedule_records)
            schedule_df.to_csv(output_csv, index=False)
            schedule_df.to_json(output_json, orient="records", lines=True)
            print(f"Schedule saved to {output_csv} and {output_json}")
        except Exception as e:
            print(f"Error saving schedule: {e}")
            return 1

        return 0

    @staticmethod
    def schedule_league_games(
        teams: List[int],
        league: pd.Series,
        team_df: pd.DataFrame,
        venue_df: pd.DataFrame,
        schedule_records: List[Dict],
        simple_case: bool = False,
    ):
        """
        Schedule games for a specific league.

        Args:
            teams (List[int]): List of team IDs in the league.
            league (pd.Series): League details.
            team_df (pd.DataFrame): Team data.
            venue_df (pd.DataFrame): Venue data.
            schedule_records (List[Dict]): List to store scheduled games.
            simple_case (bool): Whether this is the simpler recreational league scenario.
        """
        if simple_case:
            # Simpler logic for the recreational league scenario
            number_of_weeks = 3  # Number of game days (Saturdays)
            time_slots = ["10:00 AM", "11:00 AM"]
            season_start = datetime(2024, 1, 6)  # First Saturday of the season

            # Generate all possible matchups (round-robin)
            matchups = [(teams[i], teams[j]) for i in range(len(teams)) for j in range(i + 1, len(teams))]
            random.shuffle(matchups)

            # Get venue details
            venue = venue_df.iloc[0]

            # Assign games to weeks and time slots
            current_date = season_start
            for week in range(1, number_of_weeks + 1):
                for time_slot in time_slots:
                    if not matchups:
                        break

                    # Get the next matchup
                    team1_id, team2_id = matchups.pop(0)

                    # Add the game to the schedule
                    schedule_records.append({
                        "team1Name": team_df[team_df["teamId"] == team1_id]["name"].iloc[0],
                        "team2Name": team_df[team_df["teamId"] == team2_id]["name"].iloc[0],
                        "week": week,
                        "day": current_date.strftime("%A"),
                        "time": time_slot,
                        "league": league["leagueName"],
                        "location": f"{venue['name']} Field #{venue['field']}",
                    })

                current_date += timedelta(days=7)  # Move to the next Saturday
        else:
            # Existing logic for regular cases
            number_of_matches = 12 * len(teams) / 2
            game_duration = 2  # Game duration in hours
            season_start = datetime(2024, 1, 1)
            season_end = datetime(2024, 12, 31)

            matchups = [(teams[i], teams[j]) for i in range(len(teams)) for j in range(i + 1, len(teams))]
            random.shuffle(matchups)

            current_date = season_start
            matches_count = 0

            while matchups and current_date <= season_end:
                for _, venue in venue_df.iterrows():
                    if not matchups or matches_count >= number_of_matches:
                        break

                    start_time = random.randint(9, 20)
                    matchup = matchups.pop(0)
                    team1_id, team2_id = matchup

                    schedule_records.append({
                        "team1Name": team_df[team_df["teamId"] == team1_id]["name"].iloc[0],
                        "team2Name": team_df[team_df["teamId"] == team2_id]["name"].iloc[0],
                        "week": current_date.isocalendar()[1],
                        "day": current_date.weekday() + 1,
                        "start": start_time,
                        "end": start_time + game_duration,
                        "season": current_date.year,
                        "league": league["leagueName"],
                        "location": f"{venue['name']} Field #{venue['field']}",
                    })

                current_date += timedelta(days=1)


if __name__ == "__main__":
    case_name = sys.argv[1] if len(sys.argv) > 1 else "case1"
    exit_code = Scheduler.run(case=case_name)
    sys.exit(exit_code)
